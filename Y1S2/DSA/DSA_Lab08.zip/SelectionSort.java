/*
01. Write the pseudo code of the selection sort algorithm. 
02. Implement the selection sort algorithm in java. 
03. Sort the following array using the selection sort algorithm. A = {29,10,14,37,13} 
 */

public class SelectionSort {

    public static void selectionSort(int[] A){
        int n = A.length;

        for(int j=0; j<n-1; j++){
            int smallest = j;
            for(int i=j+1; i<n; i++){
                if(A[i] < A[smallest]){
                    smallest = i;
                }
            }
            //Exchange A[j] with A[smallest]
            int temp = A[j];
            A[j] = A[smallest];
            A[smallest] = temp;
        }
    }

    public static void printArray(int[] A){
        for(int i=0; i<A.length; i++){
            System.out.print(A[i]+" ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        //Hardcoded Array
        int A[] = {29, 10, 14, 37, 13};

        System.out.println("Before sorting: ");
        printArray(A);

        System.out.println("\nAfter sorting: ");
        selectionSort(A);
        printArray(A);
    }
}
