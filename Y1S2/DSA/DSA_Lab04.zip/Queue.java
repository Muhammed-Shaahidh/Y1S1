/*
1. Create a class QueueArray that implements a queue using an array and stores integers.
2. Implement the following methods:
    • insert(int item): Adds an item to the rear.
    • remove(): Removes and returns the front  item.
    • peekFront(): Returns the front item without removing it.
    • isEmpty(): Checks if the queue is empty.
    • isFull(): Checks if the queue is full.
3. Introduce a new method named getCount() to get the number of elements in the Queue.
4. Write a main method to test the queue operations.
 */

public class Queue {
    private int[] queue;
    private int front;
    private int rear;
    private int size;
    private int count;

    public Queue(int size) {
        this.size = size;
        queue = new int[size];
        front = 0;
        rear = -1;
        count = 0;
    }

    public void insert(int item) {
        if (isFull()) {
            System.out.println("Queue is full. Cannot insert item.");
            return;
        }

        rear = (rear + 1) % size;
        queue[rear] = item;
        count++;
    }

    public int remove() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot remove item.");
            return -1;
        }

        int item = queue[front];
        front = (front + 1) % size;
        count--;
        return item;
    }

    public int peekFront() {
        if (isEmpty()) {
            System.out.println("Queue is empty. No front item.");
            return -1;
        }

        return queue[front];
    }

    public boolean isEmpty() {
        return count == 0;
    }

    public boolean isFull() {
        return count == size;
    }

    public int getCount() {
        return count;
    }

    public void displayQueue() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }

        System.out.print("Queue elements: ");
        for (int i = 0; i < count; i++) {
            System.out.print(queue[(front + i) % size] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Queue queue = new Queue(5);

        queue.insert(10);
        queue.insert(20);
        queue.insert(30);
        queue.displayQueue();

        int removedItem = queue.remove();
        System.out.println("Removed: " + removedItem);
        queue.displayQueue();

        int frontItem = queue.peekFront();
        System.out.println("Front Element: " + frontItem);

        System.out.println("Queue Count: " + queue.getCount());

        System.out.println("...Program finished with exit code 0");
    }
}