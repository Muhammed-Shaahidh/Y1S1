public class Main {
    public static void main(String[] args) {
        List list= new List();

        list.insertFirst(101,85);
        list.insertFirst(102,90);
        list.insertAfter(101,103,75);

        System.out.println("List after insertions: ");
        list.displayList();
        list.delete(102);

        System.out.println("List after deleting ID 102: ");
        list.displayList();
        list.deleteFirst();

        System.out.println("List after deleting first element: ");
        list.displayList();
    }
}
