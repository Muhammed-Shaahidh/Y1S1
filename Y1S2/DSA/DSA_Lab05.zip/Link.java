/*
1. Implement a Link class to store hold student id and marks. Determine the properties of the 
link and implement constructor accordingly. Include a displayLink() to display all data 
properties of the link. 
 */

public class Link {
    int id;
    int marks;
    Link next;

    Link(int id, int marks){
        this.id = id;
        this.marks = marks;
        this.next = null;
    }

    public void displayLink(){
        System.out.println("ID: " +id +", Marks: " +marks);
    }
}
