/*
2. Implement the Linked List class with the basic properties, constructor and isEmpty() 
method. 
3. Include following methods to the Linked List class assuming a singly linked list. the 
following methods: 
    • InsertFirst(int id, int marks) – Insert new student record as the first  
    • InsertAfter(int key, int id, int marks) – Finds for student id and insert the new 
      student record after 
    • Find(int key) - Finds for student id 
    • DeleteFirst() – Delete element as the first reference 
    • Delete(int key) – Finds for student id and delete it. Need to address instances 
      where list is empty, key can be at first, and key can be at middle. 
4. Write a main method to test the LinkedList operations.
 */

public class List {
    private Link first;

    public List(){
        first = null;
    }
    public boolean isEmpty(){
        return (first == null);
    }
    public void insertFirst(int id, int marks){
        Link newLink = new Link(id, marks);
        newLink.next = first;
        first = newLink;
    }

    public boolean insertAfter(int key, int id, int marks){
        Link current = first;
        while(current != null && current.id != key){
            current = current.next;
        }
        Link newLink = new Link(id, marks);
        newLink.next = current.next;
        current.next = newLink;
        return  true;
    }

    public Link find(int key){
        Link current = first;
        while (current != null){
            if(current.id == key){
                return  current;
            }
            current = current.next;
        }
        return  null;
    }

    public Link deleteFirst(){
        if(first == null){
            return null;
        }
        Link temp = first;
        first = first.next;
        return  temp;
    }

    public boolean delete(int key){
        if(first == null){
            return  false;
        }
        if(first.id == key){
            first = first.next;
            return  true;
        }
        Link current = first;
        Link previous = first;

        while (current != null && current.id != key){
            previous = current;
            current = current.next;
        }
        if(current.next == null){
            return false;
        }
        previous.next = current.next;
        return true;
    }

    public void displayList(){
        Link current = first;
        while (current != null){
            current.displayLink();
            current = current.next;
        }
    }
}
