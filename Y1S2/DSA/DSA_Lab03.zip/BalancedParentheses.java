/*
Assume the above StackArray class. You need to introduce a new method to this class to
check whether parentheses are balanced. Write Java code segment for boolean
isBalanced(String str) to take a string input from the user. Using the stack data structure
your program should return true for balanced parentheses i.e. {[()]}, and false for
imbalanced parentheses i.e. {{((]})].  
 */

import java.util.Scanner;
import java.util.Stack;

public class BalancedParentheses {

    public static boolean isBalanced(String str) {
        Stack<Character> stack = new Stack<>();

        for (char ch : str.toCharArray()) {
            if (ch == '(' || ch == '{' || ch == '[') {
                stack.push(ch); // Push opening brackets onto the stack
            } else if (ch == ')' || ch == '}' || ch == ']') {
                if (stack.isEmpty()) {
                    return false; // No matching opening bracket
                }
                char top = stack.pop();
                if (!isMatchingPair(top, ch)) {
                    return false; // Mismatched pair
                }
            }
        }
        return stack.isEmpty(); // If stack is empty, parentheses are balanced
    }

    private static boolean isMatchingPair(char open, char close) {
        return (open == '(' && close == ')') ||
                (open == '{' && close == '}') ||
                (open == '[' && close == ']');
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string of parentheses: ");
        String input = scanner.nextLine();
        System.out.println("Balanced: " + isBalanced(input));
        scanner.close();
    }
}

