/*
Modify the above program to take a string input. Your program needs to take the input 
from the user and print the reversed user input. Hint: You may have to change the stack to 
store characters. 
 */

import java.util.Scanner;

public class StackChar {
    private final int maxSize;
    private int top;
    private final char[] stackArray;

    public StackChar(int size) {
        this.maxSize = size;
        this.stackArray = new char[maxSize];
        this.top = -1;
    }

    public void push(char item) {
        if (isFull()) return;
        stackArray[++top] = item;
    }

    public char pop() {
        if (isEmpty()) return '\0';
        return stackArray[top--];
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == maxSize - 1;
    }

    public static String reverseString(String input) {
        StackChar stack = new StackChar(input.length());

        // Push each character onto the stack
        for (char ch : input.toCharArray()) {
            stack.push(ch);
        }

        // Pop characters to get the reversed string
        StringBuilder reversed = new StringBuilder();
        while (!stack.isEmpty()) {
            reversed.append(stack.pop());
        }

        return reversed.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        System.out.println("Reversed string: " + reverseString(input));
        scanner.close();
    }
}
