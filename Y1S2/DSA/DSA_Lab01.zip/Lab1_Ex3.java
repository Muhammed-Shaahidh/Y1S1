import java.util.Scanner;
import java.util.Arrays;

public class Lab1_Ex3 {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);

        int num[] = new int[3];

        for(int i=0; i<3; i++){

            System.out.println("Enter number " +(i+1) +" :");
            num[i] = input.nextInt();
        }

        int max = Arrays.stream(num).max().getAsInt();

        System.out.println("Maximum value is " +max);

    }
}
