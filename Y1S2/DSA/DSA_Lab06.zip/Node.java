/*
01. Implement a Node class with suitable attributes to store employee number and name of 
employees.  
02. Implement displayNode ( ) method to display the details stored in a Node.
 */

// Node.java
public class Node {
    int empNo;
    String name;
    Node left;
    Node right;

    public Node(int empNo, String name) {
        this.empNo = empNo;
        this.name = name;
    }

    public void displayNode() {
        System.out.printf("%03d  %-10s%n", empNo, name);
    }
}
