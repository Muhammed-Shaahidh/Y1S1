/*
03. Implement the Tree class with the following data members and methods.  
04. Implement a new method called findRecursive( int emp) which perform the find operation 
recursively.  
05. Implement a method called deleteAll( ) to remove all the Nodes from the tree. 
 */

// Tree.java
public class Tree {
    private Node root;

    // Iterative insert
    public void insert(int empNo, String name) {
        Node newNode = new Node(empNo, name);
        if (root == null) {
            root = newNode;
            return;
        }
        Node current = root, parent = null;
        while (true) {
            parent = current;
            if (empNo < current.empNo) {
                current = current.left;
                if (current == null) {
                    parent.left = newNode;
                    return;
                }
            } else {
                current = current.right;
                if (current == null) {
                    parent.right = newNode;
                    return;
                }
            }
        }
    }

    // Iterative find
    public Node find(int empNo) {
        Node current = root;
        while (current != null && current.empNo != empNo) {
            current = (empNo < current.empNo) ? current.left : current.right;
        }
        return current;  // null if not found
    }

    // Public recursive find
    public Node findRecursive(int empNo) {
        return findRecursive(root, empNo);
    }

    private Node findRecursive(Node node, int empNo) {
        if (node == null || node.empNo == empNo)
            return node;
        if (empNo < node.empNo)
            return findRecursive(node.left, empNo);
        else
            return findRecursive(node.right, empNo);
    }

    // In-order traversal
    public void inOrder() {
        inOrder(root);
        System.out.println();
    }

    private void inOrder(Node node) {
        if (node == null) return;
        inOrder(node.left);
        node.displayNode();
        inOrder(node.right);
    }

    // Pre-order traversal
    public void preOrder() {
        preOrder(root);
        System.out.println();
    }

    private void preOrder(Node node) {
        if (node == null) return;
        node.displayNode();
        preOrder(node.left);
        preOrder(node.right);
    }

    // Post-order traversal
    public void postOrder() {
        postOrder(root);
        System.out.println();
    }

    private void postOrder(Node node) {
        if (node == null) return;
        postOrder(node.left);
        postOrder(node.right);
        node.displayNode();
    }

    // Delete all nodes
    public void deleteAll() {
        root = null;
    }
}
