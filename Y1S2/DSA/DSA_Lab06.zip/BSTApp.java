/*
06. Write an application to do the following.

                    Employee Number             Name
                    149                         Anusha
                    167                         Kosala
                    47                          Dinusha
                    66                          Mihiri
                    159                         Jayani
                    118                         Nimal
                    195                         Nishantha
                    34                          Avodya
                    105                         Bimali
                    133                         Sampath

        i. Create a tree of 10 Nodes with above details
        ii. Display the employee data using inorder, preorder and postorder traversing.
        iii. Allow the user to input any employee number from the keyboard and display the employee details if the employee exists in the tree.
        iv. Delete all the nodes from the binary search tree.
        v. Display the tree after deleting nodes.
 */


// BSTApp.java
import java.util.Scanner;

public class BSTApp {
    public static void main(String[] args) {
        Tree tree = new Tree();

        // i. Insert the 10 employees
        tree.insert(149, "Anusha");
        tree.insert(167, "Kosala");
        tree.insert( 47, "Dinusha");
        tree.insert( 66, "Mihiri");
        tree.insert(159, "Jayani");
        tree.insert(118, "Nimal");
        tree.insert(195, "Nishantha");
        tree.insert( 34, "Avodya");
        tree.insert(105, "Bimali");
        tree.insert(133, "Sampath");

        // ii. Display traversals
        System.out.println("=== In-order Traversal ===");
        tree.inOrder();
        System.out.println("=== Pre-order Traversal ===");
        tree.preOrder();
        System.out.println("=== Post-order Traversal ===");
        tree.postOrder();

        // iii. Search for an employee
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter employee number to search: ");
        int key = sc.nextInt();

        Node foundIter = tree.find(key);
        System.out.print("Iterative search: ");
        if (foundIter != null) foundIter.displayNode();
        else System.out.println("Employee not found.");

        Node foundRec = tree.findRecursive(key);
        System.out.print("Recursive search: ");
        if (foundRec != null) foundRec.displayNode();
        else System.out.println("Employee not found.");

        // iv. Delete all nodes
        tree.deleteAll();
        System.out.println("All nodes deleted.");

        // v. Show tree after deletion
        System.out.println("Tree after deleteAll (should print nothing):");
        tree.inOrder();

        sc.close();
    }
}
