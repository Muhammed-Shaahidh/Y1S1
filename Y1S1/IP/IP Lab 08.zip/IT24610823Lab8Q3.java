/*
Write a Java program to create an integer array of size 6.
 Input numbers from the keyboard and store 6 positive numbers in the array.
 If a negative number or zero is entered, display an error message.
 Finally, find the maximum number.
 
 Note: A total of 6 positive numbers should be stored in the array
 */

import java.util.Scanner;

public class IT24610823Lab8Q3{
public static void main(String[]args){

Scanner input= new Scanner(System.in);

int myArray[]= new int[6];

for(int num=0; num<=5; num++){
System.out.print("Enter a Positive Number (" +(num+1)+ "/6): ");
myArray[num]= input.nextInt();

if(myArray[num]==0 || myArray[num]<0){

System.out.println("Error: Please Enter ONLY Positive Numbers");

System.out.print("Enter a Positive Number (" +(num+ 1)+ "/6): ");
myArray[num]= input.nextInt();

}

}

System.out.println();
System.out.println("Array Contents:");

for(int num=0; num<=5; num++){

System.out.print(+myArray[num]+ " ");

}
System.out.println();
System.out.print("The Maximum Number Entered: ");

int max= myArray[0];
for(int num=0; num<=5; num++){

if(myArray[num] > max){
max= myArray[num];
}

}
System.out.print(+max);
}

}