/*
 Create another array called evenArray. Find the even numbers of array myArray
 and store them in evenArray.
 */

import java.util.Scanner;

public class IT24610823Lab8Q1B{
public static void main(String[]args){

Scanner input= new Scanner(System.in);

int myArray[]= new int[5];

System.out.println("Enter 5 Numbers:");

for(int num=0; num<=4; num++){

System.out.print("Enter Number" +(num+ 1)+ ":");
myArray[num]= input.nextInt();

}

System.out.println();
System.out.println("myArray Contents: ");

for(int num=0; num<=4; num++){

System.out.print(myArray[num]+ " ");
}

System.out.println();
System.out.println();
System.out.println("evenArray Contents:");

for(int num=0; num<=4; num++){

if(myArray[num]% 2 ==0){
System.out.print(myArray[num]+ " ");
}

else{
System.out.print("0"+ " ");
}

}

}

}