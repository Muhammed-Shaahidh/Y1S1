/*
Write a Java program to input numbers via keyboard to an array called myArray.
 Size of the array is 5.
 Print the contents of the myArray in the reverse order you entered.
 */

import java.util.Scanner;

public class IT24610823Lab8Q1A{
public static void main(String[]args){

Scanner input= new Scanner(System.in);

int[] myArray= new int[5];

System.out.println("Enter 5 Numbers:");

for(int count= 0; count<5; count++){

System.out.print("Enter Number" +(count+1)+ " :");
myArray[count]= input.nextInt();

}
System.out.println();


System.out.println("Array in Reverse Order: ");

for(int count=4; count>=0; count--){

System.out.print(myArray[count]+" ");
}

}

}