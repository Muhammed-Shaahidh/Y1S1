/*
 Write a Java program to add the content of array A and B and store it in a new array
 called C.
 
 int A[5] = 10, 20, 30, 40, 50;
 int B[5] = 34, 67, 12, 89, 12;
 int C[5];
 
 Calculate A+B and store in Array C
 */

import java.util.Scanner;

public class IT24610823Lab8Q2{
public static void main(String[]args){

Scanner input= new Scanner(System.in);

int A[]= new int[5];

System.out.println("A Array Contents: ");

for(int num=0; num<=4; num++){
A[num]= input.nextInt();
}

System.out.println();

int B[]= new int[5];

System.out.println("B Array Contents: ");


for(int num=0; num<=4; num++){
B[num]= input.nextInt();
}

System.out.println("C Array Contents (A + B): ");

int sum=0;
for(int num=0; num<=4; num++){
sum= A[num] + B[num];

System.out.print(+sum+ " ");
}

}

}