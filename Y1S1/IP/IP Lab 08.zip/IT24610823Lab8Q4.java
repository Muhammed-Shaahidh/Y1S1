/*
 Write a Java program to insert Student IDs of 8 students and store in an array called
 studentsArray. If a negative number or zero is entered, display an error message.

 Then ask user to enter a Student ID from the keyboard and find whether the Student ID
 is available in the array:
     • Display message ‘Student is Available’ if the student is found.
     • Display message ‘Student is Not Available’ if the student is not found.
 */

import java.util.Scanner;

public class IT24610823Lab8Q4{
public static void main(String[]args){

Scanner input= new Scanner(System.in);

int studentArray[]= new int[8];

for(int num=0; num<= 7; num++){

System.out.print("Enter Student ID for Student " +(num+ 1)+ ": ");
studentArray[num]= input.nextInt();

if(studentArray[num]== 0 || studentArray[num]< 0){

System.out.println("Error: Please Enter ONLY Positive Numbers");

System.out.print("Enter Student ID for Student " +(num+ 1)+ ": ");
studentArray[num]= input.nextInt();

}

}
System.out.println();
System.out.print("Enter a Student ID to Search: ");
int id= input.nextInt();
boolean found = false;

for(int num=0; num<=7; num++){

if(studentArray[num] == id){
found = true;
break;
}

}
System.out.println();
if(found){
System.out.println("Student is Available");
}

else{
System.out.println("Student is Not Available");
}

}

}
