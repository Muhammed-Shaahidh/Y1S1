/*
 a) Write a Java program that checks if a mark entered from the keyboard is within
 the valid range of 0 to 100 (inclusive).
 Use assertions to verify that the mark is within the specified range. If the mark
 is outside this range, the program should throw an Assertion Error with the
 message ‘Invalid Mark’. If the mark is valid, display the message ‘Mark is
 Validated’.
 
 b) Modify the above program to determine the Grade.
 If the mark is valid, the program should then determine the corresponding letter
 grade: ‘A’ for marks 75 and above, ‘B’ for marks 60 to 74, ‘C’ for marks 50 to 59,
 ‘D’ for marks 40 to 49, and ‘F’ for marks below 40.
 Use assertions to verify the grade assigned. If the grade assigned is incorrect, the
 program should throw an Assertion Error with the message ‘Incorrect Grade
 Assigned’.
 */

import java.util.Scanner;

public class IT24610823Lab10Q1{
    public static void main(String[]args){

        Scanner input= new Scanner(System.in);

        System.out.print("Enter the mark ( 0 - 100 ): ");
        int mark = input.nextInt();

        assert mark <= 100  && mark >= 0: "Invalid Mark";

        System.out.println();
        System.out.println("Mark is Validated");
           
        char grade;

        if(mark >= 75)
        grade = 'A';
            
        else if(mark >= 60)
        grade = 'B';

        else if(mark >= 50)
        grade = 'C';

        else if(mark >= 40)
        grade = 'D';

        else
        grade = 'F';

       assert (grade == 'A' && mark >= 75) || (grade == 'B' && mark >= 60 && mark <= 74) ||  (grade == 'C' && mark >= 50 && mark <= 59) || (grade == 'D' && mark >= 40 && mark <= 49) || (grade == 'F' && mark <= 39 ) : "Incorrect Grade Assigned";

       System.out.println("The Grade for the Entered Mark is: " +grade);   

        }

        
}