/*
 Write a Java program to display the square and square-root of any number, input by the
 user.
 */

import java.util.Scanner;

public class IT24610823Lab6Q1{
public static void main(String[]args){

Scanner input= new Scanner(System.in);

System.out.print("Enter a number: ");
int Num= input.nextInt();

double sq= Num* Num;

double sqrt= Math.sqrt(Num);

System.out.println("The square of " +Num+ " is: " +sq);
System.out.println("The square root of " +Num+ " is: " +sqrt);

}

}