/*
 Write a Java program to print the result of the following using a while loop.
 1 2 3 4 5 6 7 8 9 10
 */

import java.util.Scanner;

public class IT24610823Lab6Q2A{
public static void main(String[]args){

int num=1;

while (num<=10){

System.out.print(num +" ");
num++;

}

}

}