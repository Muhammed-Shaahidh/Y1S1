/*
Modify the program again to display the Sum and Average of the numbers entered.
 */

import java.util.Scanner;

public class IT24610823Lab6Q2C{
public static void main (String[]args){

Scanner input = new Scanner(System.in);

System.out.println("Please enter 10 numbers: ");

int[] number = new int[10];
int num= 1;

while (num <= 10){

System.out.print("Enter number " + num + ": ");
number[num - 1] = input.nextInt();

num++;

}

int sum= 0;
num= 1;
while(num<= 10){
sum += number[num - 1];
num++;
}

double aver= sum / 10.0;


System.out.print("\n");

System.out.println("The numbers you entered are: ");
num=1;
while (num <= 10){
System.out.print(number[num - 1] + " ");
num++;

}

System.out.print("\n");
System.out.println("Sum of the numbers: " +sum);
System.out.print("Average of the numbers: " +aver);

}

}






