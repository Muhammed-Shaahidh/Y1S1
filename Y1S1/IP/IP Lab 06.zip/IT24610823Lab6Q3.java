/*
Write a Java program to find the Root Mean Square of a series of numbers.
 You are required to enter a set of positive numbers (integers) terminated by-99. Validate
 for negative input.
 Use the following formula to find the Root Mean Square of the numbers entered.
 
        Root Mean Square =  √(ΣX²/N)
        
  N is the number of numbers entered.
 */

import java.util.Scanner;

public class IT24610823Lab6Q3{
public static void main(String[]args){

Scanner input= new Scanner(System.in);

System.out.println("Enter positive integers (terminate input with -99):");

int num=1;
int number;
double sq = 0;

while(num> 0){

System.out.print("Enter a number: ");
number = input.nextInt();

if (number<0 && number!= -99){
System.out.println("Invalid input. Please enter a positive integer or -99 to terminate ");
}

else if (number== -99){
break;
}

else if (number>0){
sq += Math.pow(number, 2);
num++;
}

}

double rms= Math.sqrt(sq / (num- 1) );

System.out.print("The Root Mean Square (RMS) is: " +rms);
}

}