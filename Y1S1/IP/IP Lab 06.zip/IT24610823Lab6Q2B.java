/* 
 Modify your Java program to enter 10 numbers from the keyboard as user input
 and print the result.
 */

import java.util.Scanner;

public class IT24610823Lab6Q2B{
public static void main (String[]args){

Scanner input = new Scanner(System.in);

System.out.println("Please enter 10 numbers: ");

int[] number = new int[10];
int num= 1;

while (num <= 10){

System.out.print("Enter number " + num + ": ");
number[num- 1] = input.nextInt();

num++;

}

System.out.print("\n");

System.out.println("The numbers you entered are: ");
num=1;
while (num <= 10){
System.out.print(number[num- 1] + " ");
num++;

}


}

}






