/*
 Write a Java program to input a number from the keyboard and display whether it is
 Positive or Negative. If user input 0, display number is Zero.
 */
import java.util.Scanner;

public class IT24610823Lab4Q1{
public static void main(String[]args){

int Number;

Scanner input=new Scanner(System.in);

System.out.println("Enter a number:");
Number= input.nextInt();

if (Number>0){
System.out.println("This number is positive.");
}

else if (Number<0){
System.out.println("This number is negative");
}

else {
System.out.println("This number is Zero");
}

}

}
