/*
 Final mark of a module is calculated by considering two components, exam marks and
 lab submission marks. The percentages taken from each component as the final mark.
 Write a Java program to:
 
 • Input the exam marks (given out of 100) and the lab submission marks (given out
 of 100) from the keyboard
 • Validate the entered marks (should be greater than or equal to 0 and less than or
 equal to 100)
 • Input the percentage taken from the exam mark and the lab submission mark from
 the keyboard
 • Validate the values (entered percentages should add to 100)
 • Calculate the final exam marks
 */

import java.util.Scanner;

public class IT24610823Lab4Q2{
public static void main(String[]args){

double Exam_marks, Exam_percentage;
double Lab_marks, Lab_percentage;

Scanner input=new Scanner(System.in);

System.out.println("Please enter exam marks(Out of 100):");
Exam_marks=input.nextDouble();
if(Exam_marks<=0 || Exam_marks>=100){
System.out.println("Invalid input for exam marks. Terminating program.");
return;
}

System.out.println("Please enter lab submission marks:");
Lab_marks=input.nextDouble();
if (Lab_marks<=0 || Lab_marks>=100){
System.out.println("Invalid input for exam marks. Terminating program.");
return;
}

System.out.println("Please enter the percentage given for the exam:");
Exam_percentage=input.nextDouble();
if (Exam_percentage<=0 || Exam_percentage>=100){
System.out.println("Please enter the percentage between 0-100");
return;
}

System.out.println("Please enter the percentage given for the lab submission:");
Lab_percentage=input.nextDouble();
if (Lab_percentage<=0 || Lab_percentage>=100){
System.out.println("Please enter the percentage between 0-100");
return;
}

if(Exam_percentage + Lab_percentage>100){
System.out.println("The percentages must add up to 100. Terminating program.");
return;
}

Double Final_marks= ( Exam_marks* Exam_percentage/ 100 + Lab_marks* Lab_percentage/ 100);

System.out.println("Final Exam Marks Is:" +Final_marks);

}

}