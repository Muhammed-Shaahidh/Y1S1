/*
Write a Java program to Q1 using Ternary Operator (? :) to check if the number is
 Positive or Negative or Zero.
 */

import java.util.Scanner;

public class IT24610823Lab4Q3{
public static void main(String[]args){

Integer Number;

Scanner input= new Scanner(System.in);

System.out.println("Enter a number:");
Number=input.nextInt();

String num= (Number> 0)? "The number is positive.":
	(Number< 0)? "The number is negative.":
	"The number is Zero.";

System.out.println(num);

}

}