/*
 An employee is paid an additional amount to his monthly salary as OT amount.
 Write a Java program to input the monthly salary, number of OT hours and OT hourly
 rate from the keyboard to find the total salary.
 
 OT Amount = OT hours * OT Hourly Rate
 Total Salary = Monthly Salary + OT Amount
 */

import java.util.Scanner;

public class IT24610823Lab3Q2{
public static void main(String[]args){

double monthly_salary, OT_hours, OT_hourly_rate, OT_amount, total;

Scanner input=new Scanner(System.in);

System.out.println("Enter the monthly salary:");
monthly_salary= input.nextDouble();

System.out.println("Enter the number of OT hours:");
OT_hours= input.nextDouble();

System.out.println("Enter the OT hourly rate:");
OT_hourly_rate= input.nextDouble();


OT_amount= OT_hours* OT_hourly_rate;
total= monthly_salary+ OT_amount;

System.out.println("Total Salary including OT is" +total);

}


}

