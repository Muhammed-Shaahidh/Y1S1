/*
The supermarket is giving a 10% discount on the total bill.

 Modify the Java program and find the amount you have to pay after considering the
 discount.
 */

import java.util.Scanner;

public class IT24610823Lab3Q1B{
public static void main (String[]args){

double price, num, total, discount;

Scanner input= new Scanner(System.in);

System.out.println("Enter the price of 1kg of rice:");
 price= input.nextDouble();

System.out.println("Enter the number of kg:");
num= input.nextDouble();

discount= 0.9;

total= (price* num)* discount;

System.out.println("Total amount with 10% discount is" + total);

}

}




