/*
 Write a Java program to enter a rupee amount and print the number of 5000/=, 1000/=,
 500/=, 200/=, 100/=, 50/=, 20/=, 10/=, 5/=, 2/=, 1/= notes and coins in that amount.
 */

import java.util.Scanner;

public class IT24610823Lab3Q3{
public static void main(String[]args){

int Amount, Amount1, Amount2, Amount3, Amount4, Amount5, Amount6, Amount7, Amount8, Amount9, Amount10, Remainder, Remainder1, Remainder2, Remainder3, Remainder4, Remainder5, Remainder6, Remainder7, Remainder8, Remainder9, Remainder10;

Scanner input= new Scanner(System.in);


System.out.println("Enter the amount:");
int amount= input.nextInt();

Amount= amount/ 5000;
Remainder= amount% 5000;

Amount1= Remainder/ 1000;
Remainder1= Remainder% 1000;

Amount2= Remainder1/ 500;
Remainder2= Remainder1% 500;

Amount3= Remainder2/ 200;
Remainder3= Remainder2% 200;

Amount4= Remainder3/ 100;
Remainder4= Remainder3% 100;

Amount5= Remainder4/ 50;
Remainder5= Remainder4% 50;

Amount6= Remainder5/ 20;
Remainder6= Remainder5% 20;

Amount7= Remainder6/ 10;
Remainder7= Remainder6% 10;

Amount8= Remainder7/ 5;
Remainder8= Remainder7% 5;

Amount9= Remainder8/ 2;
Remainder9= Remainder8% 2;

Amount10= Remainder9/ 1;
Remainder10= Remainder9% 1;

System.out.println("5000 Notes :" +Amount);
System.out.println("1000 Notes :" +Amount1);
System.out.println("500 Notes :" +Amount2);
System.out.println("200 Notes :" +Amount3);
System.out.println("100 Notes :" +Amount4);
System.out.println("50 Notes :" +Amount5);
System.out.println("20 Notes :" +Amount6);
System.out.println("10 Coins :" +Amount7);
System.out.println("05 Coins :" +Amount8);
System.out.println("02 Coins :" +Amount9);
System.out.println("01 Coins :" +Amount10);

}

}