/*
Enter the price of 1kg of rice and the number of kilograms you want to buy from the
 keyboard. Write a Java program to find the amount you have to pay.
 */

import java.util.Scanner;

public class IT24610823Lab3Q1A{
public static void main (String[]args){

double price, num, total;

Scanner input= new Scanner(System.in);

System.out.println("Enter the price of 1kg of rice:");
 price= input.nextDouble();

System.out.println("Enter the number of kg:");
num= input.nextDouble();

total= price* num;

System.out.println("Total amount is" + total);

}

}




