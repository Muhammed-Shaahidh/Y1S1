/*
WriteaJavaprogramtodisplaybelowpattern.
 55555
 4444
 333
 22
 1
 */

import java.util.Scanner;

public class IT24610823Lab7Q2C{
public static void main(String[]args){

int row=5, col=1;

while(row>0){

col=1;

while(col<=row){

System.out.print(row);
col+= 1;

}

System.out.println();
row--;
}

}

}