/*
 Modifyyour program to get four subjects inputs in a single line (separated by space)
 and display the grades for three (3) students.
 */

import java.util.Scanner;

public class IT24610823Lab7Q1B{
public static void main(String[]args){

Scanner input= new Scanner(System.in);

int stu=1, sum=0;

while(stu<= 3){

System.out.println("Student " +stu );
stu++;

System.out.print("Enter marks : ");
sum=0;
for(int count=1; count<=4; count++){

int marks= input.nextInt();

sum += marks;

}

double Aver= sum/4.0;

System.out.println("Average is: " +Aver);

System.out.print("Overall Grade is : ");

if(Aver>= 75){
System.out.println("Distinction");
}

else if(Aver>= 50){
System.out.println("Credit");
}

else{
System.out.println("Fail");
}
System.out.println();
}

}

}