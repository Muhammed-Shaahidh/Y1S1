/*
 Write a Java program to display numbers from 1– 5 and display the stars as shown
 below.
 1- *
 2- * *
 3- * * *
 4- * * * *
 5- * * * * *
 */

import java.util.Scanner;

public class IT24610823Lab7Q2B{
public static void main(String[]args){

int row=1, col=1;

while(row<=5){

col=1;

while(col<=row){

System.out.print("*");
col+= 1;

}
System.out.println();

row++;
}

}


}