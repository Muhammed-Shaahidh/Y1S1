/*
Write a java program to display the below figure.
 $ $ $ $ $
 $ $ $ $ $
 $ $ $ $ $
 $ $ $ $ $
 */

import java.util.Scanner;

public class IT24610823Lab7Q2A{
public static void main(String[]args){

int row=1;

while(row<=4){

System.out.println( "$ $ $ $ $");

row++;
}

}

}