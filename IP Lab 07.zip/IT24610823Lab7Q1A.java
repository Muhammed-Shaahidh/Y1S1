/*
Write a Java program to display the grade of a student.

 The user should enter marks for four subjects and find the average. The overall
 grade (based on average) is assigned as follows:
 
            Marks             Grade
           100- 75          Distinction
           74- 50            Credit
            49- 0             Fail
 */

import java.util.Scanner;

public class IT24610823Lab7Q1A{
public static void main(String[]args){

Scanner input= new Scanner(System.in);

System.out.println("Enter marks four subjects: ");

int num=1;
int sum=0;

while(num<=4){

System.out.print("Enter subject Mark " +num+ " :"  );
int Mark=input.nextInt();

num++;

sum += Mark;

}

double Average= sum/4.0;
System.out.println("Average is : " +Average);

if(Average<=100 && Average>=75){
System.out.println("Overall Grade is : Distinction");
}

else if(Average<=74 && Average>=50){
System.out.println("Overall Grade is : Credit");
}

else if(Average<=49 && Average>=0){
System.out.println("Overall Grade is : Fail");
}

}

}


